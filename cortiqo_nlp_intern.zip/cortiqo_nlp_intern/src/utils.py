# Simple helper functions
def clean_text(text):
    """Basic text cleaning"""
    return text.strip().lower()

print("Utils loaded - nothing fancy")