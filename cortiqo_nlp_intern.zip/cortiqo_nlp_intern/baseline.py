import torch
from datasets import load_dataset
from transformers import pipeline
import pandas as pd
from tqdm import tqdm
import random

# Load small subset of SQuAD for speed
print("Loading dataset...")
dataset = load_dataset("squad", split="validation[:500]")  # small for demo

# Use pre-trained QA pipeline (no training needed for baseline)
qa_pipeline = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")

def run_baseline():
    results = []
    for i in tqdm(range(min(100, len(dataset))), desc="Running baseline"):
        example = dataset[i]
        context = example['context']
        question = example['question']
        
        try:
            prediction = qa_pipeline(question=question, context=context)
            results.append({
                'question': question,
                'context': context[:200] + "...",  # truncated
                'true_answer': example['answers']['text'][0],
                'predicted': prediction['answer'],
                'score': prediction['score']
            })
        except:
            pass  # skip errors
    
    df = pd.DataFrame(results)
    accuracy = (df['true_answer'].str.lower() == df['predicted'].str.lower()).mean()
    print(f"Baseline Exact Match Accuracy: {accuracy:.3f}")
    df.to_csv('baseline_results.csv', index=False)
    print("Saved results to baseline_results.csv")

if __name__ == "__main__":
    run_baseline()