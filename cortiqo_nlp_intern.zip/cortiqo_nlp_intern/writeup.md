# One-Page Write-up: NLP/GenAI Track - CortiqoLabs Internship

## Chosen Direction
I picked the NLP track because I'm interested in how models understand questions and text. Used SQuAD dataset for question answering.

## Part A - Baseline
Built a simple pipeline using DistilBERT QA model (pre-trained). Loaded 500 examples from validation set. Got about 0.68 exact match accuracy on 100 samples. It's not perfect but works end-to-end. Code in baseline.py.

## Part B - Exploration
I looked at where the model fails. Interesting finding: the model struggles more with longer contexts or when the answer is not exactly a named entity. For example, it sometimes picks wrong spans in paragraphs with multiple numbers or dates.

One surprising thing: in cases with negation or complex sentences, accuracy drops. Like "not the capital" questions - model gets confused sometimes.

I also noticed it does better on simple "who/what" questions than "why/how".

## What I'd do next
With more time, I'd try fine-tuning the model on hard examples or add retrieval for open-domain QA. Maybe experiment with chain-of-thought prompting if using larger models. Also test on adversarial examples to make it more robust.

Overall, learned a lot about model limitations in reasoning! 

(Small note: had some issues with GPU memory so used CPU for most runs)