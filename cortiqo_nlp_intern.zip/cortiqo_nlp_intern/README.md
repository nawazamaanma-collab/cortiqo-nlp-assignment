# CortiqoLabs NLP/GenAI Intern Take-Home Assignment

## Overview
Chose the **NLP/GenAI track** - Question Answering / Reasoning failures using SQuAD dataset.

## How to Run
1. `pip install -r requirements.txt`
2. Run baseline: `python baseline.py`
3. Explore: `python exploration.py`

Simple end-to-end pipeline for extractive QA.

## Structure
- `baseline.py`: Basic retrieval + QA pipeline
- `exploration.py`: Analysis of model failures
- `src/`: Helper functions
- `writeup.md`: One-page summary