import pandas as pd
from baseline import run_baseline  # reuse some logic
import random

# For exploration - analyze failures
print("Loading baseline results...")
try:
    df = pd.read_csv('baseline_results.csv')
except:
    print("Running baseline first...")
    run_baseline()
    df = pd.read_csv('baseline_results.csv')

# Find failures
failures = df[df['true_answer'].str.lower() != df['predicted'].str.lower()]
print(f"Found {len(failures)} failure cases out of {len(df)}")

# Simple analysis
print("\nExamples of failures:")
for idx, row in failures.head(5).iterrows():
    print(f"Q: {row['question']}")
    print(f"True: {row['true_answer']}")
    print(f"Pred: {row['predicted']}\n")

# Save some analysis
failures.to_csv('failure_analysis.csv', index=False)
print("Saved failure cases.")